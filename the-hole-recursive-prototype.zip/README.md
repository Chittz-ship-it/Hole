# THE HOLE — Recursive Digging Prototype

Open `index.html` in a modern browser (internet connection required for the Three.js CDN).

Controls:
- WASD: move
- Mouse: look
- Left click: dig
- Shift: sprint
- Space / Ctrl: move vertically for this prototype
- E: sell haul
- R: return to surface

The prototype includes a persistent destructible 3D mine, depth progression, resources, upgrades, fuel/capacity, discoveries and the first recursive mystery hook.

Next development pass: proper voxel chunks, procedural biomes, inventory, equipment models, save system, prestige/recursive worlds, underground structures and a genuine “second hole” world.
